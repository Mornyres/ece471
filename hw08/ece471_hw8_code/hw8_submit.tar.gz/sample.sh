function myString {
	echo "In the depths of Winter I finally realized"
	echo "That within me lay an invincible Summer."
}
