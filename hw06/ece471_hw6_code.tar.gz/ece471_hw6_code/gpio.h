int gpio_set_output(int gpio);
int gpio_set_input(int gpio);
int gpio_enable(int gpio);
int init_gpios(int sda, int scl);
